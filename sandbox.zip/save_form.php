<?php
$servername = "your_mysql_server";
$username = "your_mysql_username";
$password = "your_mysql_password";
$database = "memorandum_database";

// Create connection
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Retrieve form data
$companyName = $_POST['company_name'];
$companyAddress = $_POST['company_address'];
$companyPosition = $_POST['company_position'];
$authorizedSignatory = $_POST['authorized_signatory'];
$collegeProgram = $_POST['college_program'];
$programName = $_POST['program_name'];
$programDuration = $_POST['program_duration'];
$startDate = $_POST['start_date'];
$endDate = $_POST['end_date'];
$signatureDate = $_POST['signature_date'];
$signatureLocation = $_POST['signature_location'];

// Insert data into the database
$sql = "INSERT INTO agreement_data (company_name, company_address, company_position, authorized_signatory, college_program, program_name, program_duration, start_date, end_date, signature_date, signature_location)
        VALUES ('$companyName', '$companyAddress', '$companyPosition', '$authorizedSignatory', '$collegeProgram', '$programName', $programDuration, '$startDate', '$endDate', '$signatureDate', '$signatureLocation')";

if ($conn->query($sql) === TRUE) {
    echo "Form submitted successfully!";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>
