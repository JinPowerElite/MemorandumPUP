CREATE DATABASE IF NOT EXISTS memorandum_database;
USE memorandum_database;

CREATE TABLE IF NOT EXISTS agreement_data (
    id INT AUTO_INCREMENT PRIMARY KEY,
    company_name VARCHAR(255),
    company_address VARCHAR(255),
    company_position VARCHAR(255),
    authorized_signatory VARCHAR(255),
    college_program VARCHAR(255),
    program_name VARCHAR(255),
    program_duration INT,
    start_date DATE,
    end_date DATE,
    signature_date DATE,
    signature_location VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
